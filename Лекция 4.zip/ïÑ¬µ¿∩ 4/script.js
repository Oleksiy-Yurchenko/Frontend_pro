﻿const QUESTIONS = {
    operator: 'Что вы хотите сделать? (+, -, /, *)', 
    qttyOfArgs: 'Введите количество аргументов:',
    argument: 'Введите аргумент #'
	}


const ACTIONS = {
    '+': function (argOne, argTwo) {return argOne + argTwo;},		// Без кавычек вокруг ключа не работает...
    '-': function (argOne, argTwo) {return argOne - argTwo;},
    '*': function (argOne, argTwo) {return argOne * argTwo;},
    '/': function (argOne, argTwo) {return argOne / argTwo;},
	}  


let arguments = {};       // Тут конечно лучше бы использовать массив, но нам их нельзя пока...
let answerToDisplay = '';
let result = 0;


let userAction = prompt(QUESTIONS.operator);

while(!(userAction in ACTIONS)) {
    userAction = prompt(QUESTIONS.operator);
}

	
let argNumber = +prompt(QUESTIONS.qttyOfArgs);

while (!((1 < argNumber) && (argNumber < 7))) {
    argNumber = +prompt(QUESTIONS.qttyOfArgs);
}


for (i = 1; i < argNumber+1; i++) {
    arguments[i] = +prompt(QUESTIONS.argument + i);
    while (isNaN(arguments[i])) {
        arguments[i] = +prompt(QUESTIONS.argument + i);
    }
    if (i < argNumber) {
        answerToDisplay += `${arguments[i]} ${userAction} `
    } else {
        answerToDisplay += `${arguments[i]}`;
    }
}


for (i = 2; i < argNumber+1; i++) {
    result = ACTIONS[userAction](arguments[i-1], arguments[i]);
    arguments[i] = result;
}


alert(answerToDisplay + ' = ' + result) 