let answer = prompt('What is your name?');

let greeting = answer ? 'Hello, ' + answer + '! How are you?' : 'Hello, stranger! How are you?';

alert(greeting);