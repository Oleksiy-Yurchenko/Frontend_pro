﻿const obj = {name: 'Alex', age: 33, adress: { country: 'UA', city: 'Dnipro'}}; 
const objCopy = copy(obj);


alert( objCopy.name);


function copy(inputObject) {
    const objectCopy = {};
    Object.keys(inputObject).forEach((key) => {
        return (inputObject[key] === 'object') ? 
		copy(inputObject[key]) : 
		objectCopy[key] = inputObject[key];
    });
    return objectCopy;
}
