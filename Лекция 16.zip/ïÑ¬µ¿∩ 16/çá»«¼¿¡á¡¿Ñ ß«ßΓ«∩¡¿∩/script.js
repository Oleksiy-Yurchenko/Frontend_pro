new Accordeon(document.querySelector('#container'));
