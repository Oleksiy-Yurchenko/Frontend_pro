﻿const obj = {name: 'Alex', age: 33, adress: { country: 'UA', city: 'Dnipro'}, zero: null}; 
const objCopy = copy(obj);


alert(objCopy.age);
alert(objCopy.zero);
alert(objCopy.adress.city);


function copy(inputObj) {
    const copyObj = {};
    Object.keys(inputObj).forEach((key) => {
        return ((inputObj[key] === 'object')  && (inputObj[key] !== 'null')) ?
	    copy(inputObj[key]) : copyObj[key] = inputObj[key];
    });
    return copyObj;
}


