﻿alert(getSimpleNumbers(100));


function getSimpleNumbers(number) {
    const primeArray = [];
    for (let i = 2; i <= number; i++) {
        if (isPrime(i)) primeArray.push(i);
    }
    return primeArray;
}
             
        
function isPrime(inputNumber){
    const maxDivisor = Math.floor(inputNumber / 2);
    let divisor = 2;	
    while (divisor <= maxDivisor) {
        if (!(inputNumber % divisor)) return false;
        divisor += 1;
    }
    return true;
}        
