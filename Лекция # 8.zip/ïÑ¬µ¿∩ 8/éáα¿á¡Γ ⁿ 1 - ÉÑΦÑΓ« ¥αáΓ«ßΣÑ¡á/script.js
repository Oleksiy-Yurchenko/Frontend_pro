﻿alert(getSimpleNumbers(100));


function getSimpleNumbers(number) {
    const inputArray = createPrimeArray(number);
    const outputArray = [];

    for (let i = 2; i <= number; i++) {
        if (inputArray[i]) outputArray.push(i);
    }
    return outputArray;
}



function createPrimeArray(num){
    const primeArray = [];

    for (let i = 0; i <= num; i++) {
        primeArray.push(1)
    }

    for (let i = 2; i <= (num / 2); i++) {
        for (let j = 2; j <= (num / i); j++) {
            primeArray[i*j] = null;
        }
    }

    return primeArray;
}
